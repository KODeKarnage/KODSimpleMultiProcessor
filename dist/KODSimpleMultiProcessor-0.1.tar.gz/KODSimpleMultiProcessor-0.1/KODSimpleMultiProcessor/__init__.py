from KODSimpleMultiProcessor.Multi_Processor import SimpleMultiProcessor as SMP

